//
//  RRCoreText.m
//  RRCoreText
//
//  Created by zijie feng on 10/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <CoreText/CoreText.h>
#import "RRCoreText.h"
#import "RRCTStyle.h"
#import "RRCTTextStyle.h"
#import "RRCTAttachment.h"
#import "RRCoreTextImageLoader.h"
#import "RRCTLinkElement.h"
#import "RRCTLinkStyle.h"
#import "RRAttributeStringBuilder.h"
#import "RRCTRender.h"


@interface RRCoreText (Private)


- (void)buildAttributedStringFromHtml:(NSString *)html;


@end

@interface RRCoreText (FrontColor)

- (BOOL)isColorEqualWithColor1:(UIColor *)color1 color2:(UIColor *)color2;

- (void)resetFrontColor;

@end

@interface RRCoreText (Attachment)

- (void)loadImages;

- (void)notifyAttachmentUpdated;

@end

@interface RRCoreText (Link)

@end

@implementation RRCoreText {
    NSMutableAttributedString *_attributedString;

    UIFont *_font;
    BOOL _highlighted;

    CGSize _displaySize;
    CGSize _constrainedSize;
    BOOL _displayAll;

    NSArray *_textAttachments;

    UITextAlignment _textAlignment;
    UILineBreakMode _lineBreakMode;
    UILineBreakMode _lastLineBreakMode;
    UIDataDetectorTypes _detectorTypes;

    RRCTLinkElement *_highlightedLinkElement;
@private
    UIColor *_textColor;
    UIColor *_highlightedTextColor;

    void (^_AttachmentUpdatedBlock)();

    NSArray *_linkElements;

    RRCTRender *_render;
}
@synthesize font = _font;
@synthesize highlighted = _highlighted;
@synthesize textColor = _textColor;
@synthesize highlightedTextColor = _highlightedTextColor;
@synthesize AttachmentUpdatedBlock = _AttachmentUpdatedBlock;
@synthesize textAlignment = _textAlignment;
@synthesize lineBreakMode = _lineBreakMode;
@synthesize lastLineBreakMode = _lastLineBreakMode;
@synthesize linkElements = _linkElements;


- (id)initWithHtmlContent:(NSString *)htmlContent font:(UIFont *)font {
    return [self initWithHtmlContent:htmlContent
                                font:font
                           alignment:(UITextAlignment) UITextAlignmentLeft
                       lineBreakMode:(UILineBreakMode) UILineBreakModeCharacterWrap];
}

- (id)initWithHtmlContent:(NSString *)htmlContent
                     font:(UIFont *)font
                alignment:(UITextAlignment)textAlignment
            lineBreakMode:(UILineBreakMode)lineBreakMode {
    return [self initWithHtmlContent:htmlContent
                                font:font
                           alignment:(UITextAlignment) textAlignment
                       lineBreakMode:(UILineBreakMode) lineBreakMode
                   lastLineBreakMode:(UILineBreakMode) UILineBreakModeCharacterWrap];
}

- (id)initWithHtmlContent:(NSString *)htmlContent
                     font:(UIFont *)font
                alignment:(UITextAlignment)textAlignment
            lineBreakMode:(UILineBreakMode)lineBreakMode
        lastLineBreakMode:(UILineBreakMode)lastLineBreakMode {
    return [self initWithHtmlContent:htmlContent
                                font:font
                           alignment:(UITextAlignment) textAlignment
                       lineBreakMode:(UILineBreakMode) lineBreakMode
                   lastLineBreakMode:(UILineBreakMode) lastLineBreakMode
                   dataDetectorTypes:UIDataDetectorTypePhoneNumber | UIDataDetectorTypeLink];
}

- (id)initWithHtmlContent:(NSString *)htmlContent
                     font:(UIFont *)font
                alignment:(UITextAlignment)textAlignment
            lineBreakMode:(UILineBreakMode)lineBreakMode
        lastLineBreakMode:(UILineBreakMode)lastLineBreakMode
        dataDetectorTypes:(UIDataDetectorTypes)dataDetectorTypes {
    self = [super init];
    if (self) {
        _textAlignment = textAlignment;
        _lineBreakMode = lineBreakMode;
        _lastLineBreakMode = lastLineBreakMode;
        _font = font;
        _detectorTypes = dataDetectorTypes;
        [self buildAttributedStringFromHtml:htmlContent];
        [self loadImages];
    }
    return self;
}


#pragma mark Private Property
- (RRCTRender *)render {
    if (_render == nil) {
        if (_lastLineBreakMode == _lineBreakMode)
            _render = [[RRCTRender alloc] initWithAttributedString:_attributedString
                                                         constrainedSize:_constrainedSize];
        else
            _render = [[RRCTRender alloc] initWithAttributedString:_attributedString
                                                         constrainedSize:_constrainedSize
                                                       lastLineBreakMode:_lastLineBreakMode];
    }
    return _render;
}

#pragma mark Property

- (void)setTextColor:(UIColor *)textColor {
    if ([self isColorEqualWithColor1:_textColor color2:textColor])
        return;

    _textColor = textColor;
    if (!self.highlighted)
        [self resetFrontColor];
}

- (void)setHighlightedTextColor:(UIColor *)highlightedTextColor {
    if ([self isColorEqualWithColor1:_highlightedTextColor color2:highlightedTextColor])
        return;

    _highlightedTextColor = highlightedTextColor;
    if (self.highlighted)
        [self resetFrontColor];
}

- (void)setHighlighted:(BOOL)highlighted {
    if (_highlighted == highlighted)
        return;

    _highlighted = highlighted;
    if ([self isColorEqualWithColor1:self.textColor color2:self.highlightedTextColor])
        return;

    [self resetFrontColor];
}

- (CGSize)size {
    return self.render.displaySize;
}


#pragma mark public function

- (void)sizeFit:(CGSize)constrainedSize {
    if (constrainedSize.width == 0.0 && constrainedSize.height == 0.0) {
        constrainedSize.width = CGFLOAT_MAX;
        constrainedSize.height = CGFLOAT_MAX;
    }

    _constrainedSize = constrainedSize;
    _render = nil;
}


- (void)drawInContext:(CGContextRef)context {
    [self.render drawInContext:context];

}


#pragma mark Link
- (BOOL)resetFrontColorForLinkElement:(RRCTLinkElement *)linkElement {
    if (linkElement.linkStyle && linkElement.linkStyle.selectedFrontColor) {

        UIColor *frontColor = nil;
        if (linkElement.selected)
            frontColor = linkElement.linkStyle.selectedFrontColor;
        else if (self.highlighted && linkElement.linkStyle.highlightedFrontColor)
            frontColor = linkElement.linkStyle.highlightedFrontColor;
        else
            frontColor = linkElement.linkStyle.frontColor;

        [_attributedString enumerateAttributesInRange:(NSRange) {.length = _attributedString.length}
                                              options:0
                                           usingBlock:^(NSDictionary *attrs, NSRange range, BOOL *stop) {

                                               RRCTLinkElement *element = [attrs objectForKey:kRRLinkElementAttributeName];
                                               if (element != linkElement)
                                                   return;

                                               [_attributedString addAttribute:(__bridge NSString *) kCTForegroundColorAttributeName
                                                                         value:(__bridge id) frontColor.CGColor
                                                                         range:range];


                                           }];

        _render = nil;
        return YES;
    }

    return NO;
}

- (BOOL)selectLinkAtPoint:(CGPoint)point {
    RRCTLinkElement *linkElement = [self.render linkElementAtPoint:point];
    if (linkElement == _highlightedLinkElement)
        return NO;

    BOOL needUpdate = NO;
    if (_highlightedLinkElement) {
        _highlightedLinkElement.selected = NO;
        needUpdate = [self resetFrontColorForLinkElement:_highlightedLinkElement];
    }

    _highlightedLinkElement = linkElement;

    if (_highlightedLinkElement) {
        _highlightedLinkElement.selected = YES;
        needUpdate = [self resetFrontColorForLinkElement:_highlightedLinkElement];
    }

    return needUpdate;
}

- (BOOL)deselectLink {
    BOOL needUpdate = NO;
    if (_highlightedLinkElement) {
        _highlightedLinkElement.selected = NO;
        needUpdate = [self resetFrontColorForLinkElement:_highlightedLinkElement];
        _highlightedLinkElement = nil;
    }

    return needUpdate;
}

- (NSString *)selectedLinkUrl {
    if (_highlightedLinkElement)
        return _highlightedLinkElement.href;

    return nil;
}

#pragma mark Private functions
- (void)buildAttributedStringFromHtml:(NSString *)html {
    RRAttributeStringBuilder *builder = [[RRAttributeStringBuilder alloc] initWithHtmlContent:html
                                                                                    alignment:_textAlignment
                                                                                lineBreakMode:_lineBreakMode
                                                                                     baseFont:_font
                                                                            dataDetectorTypes:_detectorTypes];
    _attributedString = [builder build];
    _textAttachments = builder.attachments;
    NSLog(@"string:%@",_attributedString);
}

#pragma mark FrontColor
- (BOOL)isColorEqualWithColor1:(UIColor *)color1 color2:(UIColor *)color2 {
    if (color1 == color2)
        return YES;

    if (color1 == nil)
        color1 = [UIColor blackColor];
    if (color2 == nil)
        color2 = [UIColor blackColor];

    return [color1 isEqual:color2];
}


- (void)resetFrontColor {
    UIColor *color = self.highlighted ? self.highlightedTextColor : self.textColor;
    if (color == nil)
        color = [UIColor blackColor];

    [_attributedString enumerateAttributesInRange:(NSRange) {.length = _attributedString.length}
                                          options:0
                                       usingBlock:^(NSDictionary *attrs, NSRange range, BOOL *stop) {
                                           UIColor *newColor = color;
                                           RRCTStyle *style = [attrs objectForKey:kRRStyleAttributeName];
                                           if (style && [style isKindOfClass:[RRCTTextStyle class]]) {
                                               RRCTTextStyle *textStyle = (RRCTTextStyle *) style;
                                               if (self.highlighted && textStyle.highlightedFrontColor)
                                                   newColor = textStyle.highlightedFrontColor;
                                               else if (!self.highlighted && textStyle.frontColor)
                                                   newColor = textStyle.frontColor;
                                           }

                                           [_attributedString addAttribute:(__bridge NSString *) kCTForegroundColorAttributeName
                                                                     value:(__bridge id) newColor.CGColor
                                                                     range:range];
                                       }];

    _render = NULL;
}

#pragma mark Attachment
- (void)loadImages {
    for (RRCTAttachment *attachment in _textAttachments) {
        if (attachment.srcUrl) {
            UIImage *cachedImage = [[RRCoreTextImageLoader instance] cachedImageForUrl:attachment.srcUrl];
            if (cachedImage) {
                attachment.image = cachedImage;
            } else {
                [[RRCoreTextImageLoader instance] loadImageFromUrl:attachment.srcUrl
                                                        completion:^(UIImage *image) {
                                                            attachment.image = image;
                                                            [self notifyAttachmentUpdated];
                                                        }];
            }
        }
    }
}

- (void)notifyAttachmentUpdated {
    dispatch_async(dispatch_get_main_queue(), ^() {
        if (self.AttachmentUpdatedBlock) {
            self.AttachmentUpdatedBlock();
        }
    });
}
@end
