//
//  RRCoreText.h
//  RRCoreText
//
//  Created by zijie feng on 10/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class RRCTLinkElement;

@interface RRCoreText : NSObject

@property(nonatomic, readonly) UIFont *font;
@property(nonatomic, assign) BOOL highlighted;
@property(nonatomic, readonly) CGSize size;
//default is nil,draw use black
@property(nonatomic, strong) UIColor *textColor;
//default is nil
@property(nonatomic, strong) UIColor *highlightedTextColor;

@property (nonatomic, copy) void (^AttachmentUpdatedBlock)();

@property(readonly) UITextAlignment textAlignment;
@property(readonly) UILineBreakMode lineBreakMode;
@property(readonly) UILineBreakMode lastLineBreakMode;

@property(nonatomic, readonly) NSArray *linkElements;

- (id)initWithHtmlContent:(NSString *)htmlContent font:(UIFont *)font;

- (id)initWithHtmlContent:(NSString *)htmlContent
                     font:(UIFont *)font
                alignment:(UITextAlignment)textAlignment
            lineBreakMode:(UILineBreakMode)lineBreakMode;

- (id)initWithHtmlContent:(NSString *)htmlContent
                     font:(UIFont *)font
                alignment:(UITextAlignment)textAlignment
            lineBreakMode:(UILineBreakMode)lineBreakMode
        lastLineBreakMode:(UILineBreakMode)lastLineBreakMode;

- (id)initWithHtmlContent:(NSString *)htmlContent
                     font:(UIFont *)font
                alignment:(UITextAlignment)textAlignment
            lineBreakMode:(UILineBreakMode)lineBreakMode
        lastLineBreakMode:(UILineBreakMode)lastLineBreakMode
                dataDetectorTypes:(UIDataDetectorTypes)dataDetectorTypes;

//UIDataDetectorTypes

//cacluate size
- (void)sizeFit:(CGSize)constrainedSize;


//render
- (void)drawInContext:(CGContextRef)context;


//url process
- (BOOL)selectLinkAtPoint:(CGPoint)point;

- (BOOL)deselectLink;

- (NSString *)selectedLinkUrl;

//- (RRCTLinkElement *)linkElementAtPoint:(CGPoint)point;

@end
